// TODO: add GQL tests
// https://medium.com/@shalkam/testing-a-graphql-server-using-jest-and-graphql-tester-a95ef25aecd8

// Update with actual GQL tests
describe("A user", () => {
  it("should register with new user", () => {
    expect(true).toBe(true);
  });
  it("should not register with existing user data", () => {
    expect(true).toBe(true);
  });
  it("should not login with wrong credentials", () => {
    expect(true).toBe(true);
  });
  it("should login with correct credentials", () => {
    expect(true).toBe(true);
  });
  it("should not login twice", () => {
    expect(true).toBe(true);
  });
  it("should logout after logging in", () => {
    expect(true).toBe(true);
  });
  it("should not logout if not logged in", () => {
    expect(true).toBe(true);
  });
  it("should removed by ID", () => {
    expect(true).toBe(true);
  });
});
